package kr.ac.daelim.uml.strategy;

public class Turtle extends Animal {
	IFly fly;
	ICry cry;
	
	public Turtle() {
		
		cry = new CryNoWay();
		fly = new FlyNoway();
		
	}
	
	public void performCry() {
		cry.cry();
	}
	
	public void performFly() {
		fly.fly();
	}
	
	public void display() {
		System.out.println("거북이 모습");
	}
	public void move() {
		System.out.println("거북이가 움직인다.");
	}
}
