package kr.ac.daelim.uml.strategy;

public class Zoo {

	public static void main(String[] args) {
		Animal tiger = new Tiger();
		Animal eagle = new Eagle();
		Animal turtle = new Turtle();
		
		tiger.performCry();
		tiger.performFly();
		tiger.display();
		tiger.move();
		System.out.println("------------------");
		
		eagle.performCry();
		eagle.performFly();
		eagle.display();
		eagle.move();
		System.out.println("------------------");
		
		turtle.performCry();
		turtle.performFly();
		turtle.display();
		turtle.move();
		
	}

}
