package kr.ac.daelim.uml.strategy;

public interface IFly {

	public void fly();

}
