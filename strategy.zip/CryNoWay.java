package kr.ac.daelim.uml.strategy;

public class CryNoWay implements ICry{
	public void cry() {
		System.out.println("울지않는다.");
	}

}
