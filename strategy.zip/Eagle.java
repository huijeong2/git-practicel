package kr.ac.daelim.uml.strategy;

public class Eagle extends Animal{
	
	public Eagle() {
		
		cry = new BirdCry();
		fly = new FlyWithWings();
	}
	
	public void performCry() {
		cry.cry();
	}
	public void performFly() {
		fly.fly();
	}
	
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("독수리모습");
	}
	
	public void move() {
		System.out.println("독수리가 움직인다.");
	}

}
