package kr.ac.daelim.uml.strategy;

public class Tiger extends Animal{
	IFly fly;
	ICry cry;
	
	public Tiger() {
	
		cry = new TigerCry();
		fly = new FlyNoway();
	}
	
	public void performCry() {
		cry.cry();
	}
	public void performFly() {
		fly.fly();
	}
	
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("호랑이 모습");
	}
	
	public void move() {
		System.out.println("호랑이가 움직인다.");
	}
	
	
}
