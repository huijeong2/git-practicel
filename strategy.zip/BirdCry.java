package kr.ac.daelim.uml.strategy;

public class BirdCry implements ICry {
	
	public void cry() {
		System.out.println("새가 운다.");
	}

}
