package kr.ac.daelim.uml.strategy;

public class FlyWithWings implements IFly {

	public void fly() {
		System.out.println("두 날개로 날다.");
	}
}
