package kr.ac.daelim.uml.strategy;

public class FlyNoway implements IFly{

	public void fly() {
		System.out.println("날지못한다.");
	}
}
